import logo from './logo.svg';
import './App.css';
import Home from './Shoping/Home'

function App() {
  return (
    
    <div className="App">
      <header className="App-header">
        <h3>
   VOGUER .. <span><i>Your perfect shopping partner</i></span>
   </h3>
      </header>
      <div className="App-body">
      <Home/>
      </div>
      
    </div>
  );
}

export default App;
